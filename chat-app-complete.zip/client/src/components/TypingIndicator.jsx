import React from 'react';
export default function TypingIndicator({names}){if(!names.length)return null;return<p>{names.join(', ')} typing...</p>; }
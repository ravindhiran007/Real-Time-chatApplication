import React,{useEffect,useRef,useState} from 'react';
import { io } from 'socket.io-client';
import { SERVER_URL } from '../api.js';
import MessageList from './MessageList.jsx';
import MessageInput from './MessageInput.jsx';
import TypingIndicator from './TypingIndicator.jsx';
export default function ChatRoom({session,onLeave}){
 const{name,room}=session;const[messages,setMessages]=useState([]);const[users,setUsers]=useState([]);const[typing,setTyping]=useState({});const socketRef=useRef();
 useEffect(()=>{const s=io(SERVER_URL);socketRef.current=s;
   s.emit('join',{name,room},res=>{if(res.ok){setMessages(res.messages);setUsers(res.users);}else onLeave();});
   s.on('message',m=>setMessages(ms=>[...ms,m]));s.on('users',u=>setUsers(u));s.on('typing',({user,isTyping})=>setTyping(t=>{const n={...t};if(isTyping)n[user]=true;else delete n[user];return n;}));
   return()=>s.disconnect();},[name,room,onLeave]);
 const send=text=>socketRef.current.emit('message',text);
 const typingFn=is=>socketRef.current.emit('typing',is);
 return(<div><h2>Room: {room}</h2><button onClick={onLeave}>Leave</button><MessageList messages={messages} selfName={name}/><TypingIndicator names={Object.keys(typing)}/><MessageInput onSend={send} onTyping={typingFn}/></div>);
}
import React,{useState} from 'react';
export default function JoinForm({onJoin}){
 const[name,setName]=useState('');
 const[room,setRoom]=useState('general');
 const handleSubmit=e=>{e.preventDefault();if(name&&room) onJoin({name,room});};
 return(<form onSubmit={handleSubmit}><input value={name} onChange={e=>setName(e.target.value)} placeholder='Name'/><input value={room} onChange={e=>setRoom(e.target.value)} placeholder='Room'/><button type='submit'>Join</button></form>);
}
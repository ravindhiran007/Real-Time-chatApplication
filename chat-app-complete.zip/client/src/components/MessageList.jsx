import React,{useEffect,useRef} from 'react';
export default function MessageList({messages,selfName}){
 const ref=useRef();useEffect(()=>{ref.current?.lastElementChild?.scrollIntoView();},[messages]);
 return(<ul className='messages' ref={ref}>{messages.map((m,i)=><li key={i}><b>{m.user===selfName?'Me':m.user}:</b> {m.text}</li>)}</ul>);
}
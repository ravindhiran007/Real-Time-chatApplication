import React,{useState} from 'react';
export default function MessageInput({onSend,onTyping}){
 const[text,setText]=useState('');
 const submit=e=>{e.preventDefault();if(text.trim()){onSend(text);setText('');}};
 return(<form onSubmit={submit}><input value={text} onChange={e=>{setText(e.target.value);onTyping(true);}}/><button>Send</button></form>);
}
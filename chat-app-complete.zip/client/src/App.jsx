import React,{useState} from 'react';
import JoinForm from './components/JoinForm.jsx';
import ChatRoom from './components/ChatRoom.jsx';
export default function App(){const[session,setSession]=useState(null);return !session?<JoinForm onJoin={setSession}/>:<ChatRoom session={session} onLeave={()=>setSession(null)}/>;}
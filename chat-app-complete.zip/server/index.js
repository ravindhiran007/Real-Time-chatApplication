import express from 'express';
import http from 'http';
import { Server } from 'socket.io';
import cors from 'cors';

const PORT = process.env.PORT || 4000;
const app = express();
app.use(cors());
app.get('/', (_req, res) => res.json({ status: 'ok' }));
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*'} });

const rooms = new Map();
function ensureRoom(room){ if(!rooms.has(room)) rooms.set(room,{messages:[],users:new Map()}); }
function getUsers(room){ return Array.from(rooms.get(room)?.users.values()||[]).map(u=>u.name); }

io.on('connection', socket => {
  let room=null, user=null;
  socket.on('join', ({name,room:r},ack)=>{
    if(!name||!r) return ack({ok:false,error:'Name and room required'});
    user=name; room=r; ensureRoom(room);
    socket.join(room);
    rooms.get(room).users.set(socket.id,{name:user});
    ack({ok:true,messages:rooms.get(room).messages,users:getUsers(room)});
    io.to(room).emit('users',getUsers(room));
  });
  socket.on('message',(text)=>{
    if(!room||!user) return;
    const msg={id:Date.now()+socket.id,user,text,time:Date.now()};
    rooms.get(room).messages.push(msg);
    io.to(room).emit('message',msg);
  });
  socket.on('typing',(isTyping)=>{
    if(room&&user) socket.to(room).emit('typing',{user,isTyping});
  });
  socket.on('disconnect',()=>{
    if(room&&rooms.get(room)){ rooms.get(room).users.delete(socket.id); io.to(room).emit('users',getUsers(room));}
  });
});

server.listen(PORT,()=>console.log('server on '+PORT));